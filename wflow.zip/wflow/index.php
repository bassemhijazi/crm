<?php
// index.php
require_once 'includes/header.php';
?>

<div class="wrapper">
    <?php require_once 'includes/sidebar.php'; ?>

    <div id="content">
        <header class="main-header d-flex align-items-center mb-4 rounded">
            <button type="button" id="sidebarCollapse" class="btn btn-light me-3">
                <i class="fas fa-align-left"></i>
            </button>
            <h2 id="pageTitle" class="h4 mb-0">Dashboard</h2>
            
            <div class="ms-auto d-flex align-items-center">
                <div class="form-check form-switch me-3">
                    <input class="form-check-input" type="checkbox" role="switch" id="themeSwitch">
                    <label class="form-check-label" for="themeSwitch"><i class="fas fa-moon"></i></label>
                </div>
                <div class="dropdown me-3">
                    <label for="roleSwitcher" class="me-2">Role:</label>
                    <select id="roleSwitcher" class="form-select form-select-sm" style="width: auto;">
                        <option value="admin" selected>Admin</option>
                        <option value="account_manager">Account Manager</option>
                        <option value="team_leader">Team Leader</option>
                        <option value="dispatcher">Dispatcher</option>
                        <option value="technician">Technician</option>
                    </select>
                </div>
                 <div class="dropdown">
                    <a href="#" class="d-block link-dark text-decoration-none dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="https://i.pravatar.cc/40?u=admin" alt="mdo" width="32" height="32" class="rounded-circle">
                    </a>
                    <ul class="dropdown-menu text-small dropdown-menu-end">
                        <li><a class="dropdown-item" href="#">Profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="#">Sign out</a></li>
                    </ul>
                </div>
            </div>
        </header>

        <main>
            <?php
            // Include all page containers. JS will toggle visibility.
            include 'pages/dashboard.php';
            include 'pages/admin.php';
            include 'pages/jobs.php';
            include 'pages/technicians.php';
            include 'pages/accounts.php';
            include 'pages/trades.php';
            include 'pages/map.php';
            include 'pages/payments.php';
            include 'pages/compliance.php';
            include 'pages/reports.php';
            ?>
        </main>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>