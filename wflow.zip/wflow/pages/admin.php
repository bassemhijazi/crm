<div id="admin" class="page">
    <div class="card">
        <div class="card-header"><h5 class="mb-0">User Management</h5></div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead><tr><th>Name</th><th>Role</th><th>Status</th><th>Actions</th></tr></thead>
                    <tbody id="adminUsersTableBody">
                        </tbody>
                </table>
            </div>
        </div>
    </div>
</div>