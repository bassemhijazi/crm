<div id="payments" class="page">
    <div class="card">
        <div class="card-header"><h5 class="mb-0">Payments & Payouts</h5></div>
        <div class="card-body"><p>This page is under construction.</p></div>
    </div>
</div>