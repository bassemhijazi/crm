<div id="trades" class="page">
    <div class="card">
        <div class="card-header"><h5 class="mb-0">Trade Management</h5></div>
        <div class="card-body">
            <div class="row mb-4">
                <div class="col-md-3"><div class="card bg-primary text-white text-center"><div class="card-body"><h4 class="card-title" id="totalTradesCount">0</h4><p class="card-text">Total Trades</p></div></div></div>
                <div class="col-md-3"><div class="card bg-success text-white text-center"><div class="card-body"><h4 class="card-title" id="activeTradesCount">0</h4><p class="card-text">Active Trades</p></div></div></div>
            </div>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead><tr><th>Trade Name</th><th>Status</th><th>Technicians</th><th>Active Jobs</th><th>Avg. Margin</th><th>Hazard Work</th><th>Actions</th></tr></thead>
                    <tbody id="tradesTableBody">
                        </tbody>
                </table>
            </div>
        </div>
    </div>
</div>