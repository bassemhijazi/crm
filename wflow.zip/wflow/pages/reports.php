<div id="reports" class="page">
    <div class="row">
        <div class="col-md-6 mb-4"><div class="card"><div class="card-header">Dispatcher Performance</div><div class="card-body"><canvas id="dispatcherPerformanceChart"></canvas></div></div></div>
        <div class="col-md-6 mb-4"><div class="card"><div class="card-header">Margin Analysis by Trade</div><div class="card-body"><canvas id="marginAnalysisChart"></canvas></div></div></div>
        <div class="col-md-6 mb-4"><div class="card"><div class="card-header">Win Rate by Account</div><div class="card-body"><canvas id="winRateChart"></canvas></div></div></div>
        <div class="col-md-6 mb-4"><div class="card"><div class="card-header">NTE Overrun Rate</div><div class="card-body"><canvas id="nteOverrunChart"></canvas></div></div></div>
    </div>
</div>