<div id="technicians" class="page">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Technician Management</h5>
            <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#newTechnicianModal">
                <i class="fas fa-plus me-1"></i> Add Tech
            </button>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead><tr><th>Name</th><th>Status</th><th>Score</th><th>Rating</th><th>Trade</th><th>Coverage (mi)</th><th>Actions</th></tr></thead>
                    <tbody id="techniciansTableBody"></tbody>
                </table>
            </div>
        </div>
    </div>
</div>