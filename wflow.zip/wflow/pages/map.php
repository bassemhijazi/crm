<div id="map" class="page">
    <div class="card">
        <div class="card-header"><h5 class="mb-0">Interactive Technician Map</h5></div>
        <div class="card-body">
           <div class="row mb-3 bg-light p-3 rounded">
                <div class="col-md-3"><label for="mapTradeFilter" class="form-label">Trade</label><select class="form-select" id="mapTradeFilter"><option value="all">All Trades</option></select></div>
                <div class="col-md-3"><label for="mapStatusFilter" class="form-label">Status</label><select class="form-select" id="mapStatusFilter"><option value="all">All Statuses</option><option>Certified</option><option>Validated</option><option>Prospect</option></select></div>
                <div class="col-md-3"><label for="mapRadiusFilter" class="form-label">Radius (mi)</label><input type="range" class="form-range" min="10" max="100" id="mapRadiusFilter" value="50"><span id="mapRadiusFilterValue">50</span> mi</div>
                <div class="col-md-3 d-flex align-items-end"><button id="applyMapFilters" class="btn btn-primary w-100">Apply Filters</button></div>
            </div>
            <div id="technicianMapContainer"></div>
        </div>
    </div>
</div>