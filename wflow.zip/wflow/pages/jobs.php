<div id="jobs" class="page">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Jobs Management</h5>
            <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#newJobModal"><i class="fas fa-plus me-1"></i> New Job</button>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead><tr><th>Job ID</th><th>Client</th><th>Trade</th><th>Status</th><th>SLA Timer</th><th>Assigned Tech</th><th>Actions</th></tr></thead>
                    <tbody id="jobsTableBody"></tbody>
                </table>
            </div>
        </div>
    </div>
</div>