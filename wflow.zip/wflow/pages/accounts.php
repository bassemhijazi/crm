<div id="accounts" class="page">
    <div class="card">
        <div class="card-header"><h5 class="mb-0">Account Management</h5></div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead><tr><th>Account Name</th><th>Billing Terms</th><th>Default NTE</th><th>SLA Profile</th><th>Active Jobs</th><th>Actions</th></tr></thead>
                    <tbody id="accountsTableBody">
                        </tbody>
                </table>
            </div>
        </div>
    </div>
</div>