<?php
// pages/job-details.php
?>
<form id="editJobForm">
    <input type="hidden" name="id">
    <div class="row">
        <div class="col-md-8">
            <div class="mb-3">
                <label class="form-label">Client Site Name</label>
                <input type="text" class="form-control" name="clientSiteName" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Job Description</label>
                <textarea class="form-control" name="description" rows="5" required></textarea>
            </div>
             <hr><div class="mb-3"><label class="form-label fw-bold">Job Site Location</label><input type="text" class="form-control" name="street" placeholder="Street Address" required></div>
             <div class="row"><div class="col-md-4 mb-3"><input type="text" class="form-control" name="city" placeholder="City" required></div><div class="col-md-4 mb-3"><input type="text" class="form-control" name="state" placeholder="State" required></div><div class="col-md-4 mb-3"><input type="text" class="form-control" name="zip" placeholder="Zip Code" required></div></div>
        </div>
        <div class="col-md-4">
            <div class="mb-3">
                <label class="form-label">Status</label>
                <select class="form-select" name="status" required>
                    <option>Pending Assignment</option>
                    <option>Pending Dispatcher</option>
                    <option>Ready for Tech Offer</option>
                    <option>En-route</option>
                    <option>Work Started</option>
                    <option>Work Complete</option>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">NTE (Not-to-Exceed)</label>
                <div class="input-group">
                    <span class="input-group-text">$</span>
                    <input type="number" class="form-control" name="nte" required>
                </div>
            </div>
        </div>
    </div>
</form>