<?php
// api/fetch_data.php
header('Content-Type: application/json');
require_once '../config/database.php';
$type = $_GET['type'] ?? '';

try {
    switch ($type) {
        case 'jobs':
            $sql = "SELECT j.job_id as id, j.account_id as account, j.client_site_name as client, t.name as trade, j.status, j.sla_due_timestamp as sla, tech.full_name as tech, j.job_location_data as location, j.job_description as notes, j.nte_amount as nte, j.street, j.city, j.state, j.zip FROM Jobs j LEFT JOIN Trades t ON j.trade_id = t.trade_id LEFT JOIN Technicians tech ON j.assigned_tech_id = tech.tech_id ORDER BY j.job_id ASC";
            $stmt = $pdo->query($sql);
            $jobs = $stmt->fetchAll();
             foreach ($jobs as &$job) {
                 $job['location'] = json_decode($job['location'], true);
                 $job['address'] = ['street' => $job['street'], 'city' => $job['city'], 'state' => $job['state'], 'zip' => $job['zip']];
                 $job['sla'] = strtotime($job['sla']) * 1000;
                 if (is_null($job['tech'])) $job['tech'] = 'Unassigned';
             }
            echo json_encode($jobs);
            break;

        case 'users':
            // UPDATED: Now fetches all users, can be filtered by role on the frontend
            $stmt = $pdo->query("SELECT user_id as id, full_name as name, email, phone, role, status FROM Users");
            echo json_encode($stmt->fetchAll());
            break;
            
        case 'technicians':
            $sql = "SELECT tech_id as id, full_name as name, status, rating, t.name as trade, coverage_radius_miles as coverage, phone, location_data as location, score, street, city, state, zip FROM Technicians LEFT JOIN Trades t ON primary_trade_id = t.trade_id";
            $stmt = $pdo->query($sql);
            $techs = $stmt->fetchAll();
            foreach ($techs as &$tech) {
                $tech['location'] = json_decode($tech['location'], true);
                $tech['address'] = ['street' => $tech['street'], 'city' => $tech['city'], 'state' => $tech['state'], 'zip' => $tech['zip']];
            }
            echo json_encode($techs);
            break;

        case 'accounts': $stmt = $pdo->query("SELECT account_id as id, name, billing_terms as billingTerms, default_nte as defaultNTE, active_jobs_count as activeJobs FROM Accounts"); echo json_encode($stmt->fetchAll()); break;
        case 'trades': $stmt = $pdo->query("SELECT trade_id as id, name FROM Trades WHERE status = 'active'"); echo json_encode($stmt->fetchAll()); break;
        default: http_response_code(400); echo json_encode(['error' => 'Invalid data type requested.']); break;
    }
} catch (PDOException $e) {
    http_response_code(500);
    error_log($e->getMessage());
    echo json_encode(['error' => 'A database error occurred.']);
}
?>