<?php
// api/texting_api.php

header('Content-Type: application/json');

// This is a simulation. In a real app, you would integrate with an SMS gateway like Twilio or Vonage.
$data = json_decode(file_get_contents('php://input'), true);

$jobId = $data['jobId'] ?? 'N/A';
$techName = $data['techName'] ?? 'N/A';
$message = $data['message'] ?? 'No message content.';

// Log the simulated SMS for demonstration purposes
error_log("SIMULATED SMS to {$techName} for Job {$jobId}: {$message}");

echo json_encode([
    'success' => true,
    'message' => "Simulated SMS sent successfully to {$techName}."
]);
?>