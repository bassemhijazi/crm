<?php
// api/manage_data.php
header('Content-Type: application/json');
require_once '../config/database.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';
$data = $input['data'] ?? [];

if (!$action) { http_response_code(400); exit; }

try {
    $pdo->beginTransaction();
    $message = '';

    switch ($action) {
        // --- JOB CRUD ---
        case 'addJob':
            $trade_stmt = $pdo->prepare("SELECT trade_id FROM Trades WHERE name = ?");
            $trade_stmt->execute([$data['trade']]);
            $trade_id = $trade_stmt->fetchColumn();
            $count_stmt = $pdo->query("SELECT COUNT(*) FROM Jobs");
            $new_job_id = 'J-' . str_pad($count_stmt->fetchColumn() + 1, 3, '0', STR_PAD_LEFT);
            $sql = "INSERT INTO Jobs (job_id, account_id, trade_id, status, client_site_name, job_description, nte_amount, street, city, state, zip) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([ $new_job_id, $data['accountId'], $trade_id, 'Pending Assignment', $data['clientSiteName'], $data['description'], $data['nte'], $data['street'], $data['city'], $data['state'], $data['zip'] ]);
            $message = "Job ${new_job_id} created.";
            break;
        case 'updateJob':
            $sql = "UPDATE Jobs SET client_site_name = ?, job_description = ?, nte_amount = ?, status = ?, street = ?, city = ?, state = ?, zip = ? WHERE job_id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([ $data['clientSiteName'], $data['description'], $data['nte'], $data['status'], $data['street'], $data['city'], $data['state'], $data['zip'], $data['id'] ]);
            if ($stmt->rowCount() === 0) throw new Exception("Job not found or data is the same.");
            $message = "Job {$data['id']} updated.";
            break;
        case 'deleteJob':
            $sql = "DELETE FROM Jobs WHERE job_id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$data['id']]);
            if ($stmt->rowCount() === 0) throw new Exception("Job not found.");
            $message = "Job {$data['id']} deleted.";
            break;
            
        // --- USER CRUD ---
        case 'addUser':
             $sql = "INSERT INTO Users (full_name, email, phone, role, status) VALUES (?, ?, ?, ?, ?)";
             $stmt = $pdo->prepare($sql);
             $stmt->execute([$data['name'], $data['email'], $data['phone'], $data['role'], $data['status']]);
             $message = "User created successfully.";
             break;
        case 'updateUser':
            $sql = "UPDATE Users SET full_name = ?, email = ?, phone = ?, role = ?, status = ? WHERE user_id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$data['name'], $data['email'], $data['phone'], $data['role'], $data['status'], $data['id']]);
            if ($stmt->rowCount() === 0) throw new Exception("User not found or data is the same.");
            $message = "User updated.";
            break;
        case 'deleteUser':
            $sql = "DELETE FROM Users WHERE user_id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$data['id']]);
            if ($stmt->rowCount() === 0) throw new Exception("User not found.");
            $message = "User deleted.";
            break;

        default:
            throw new Exception("Invalid action specified.");
    }
    $pdo->commit();
    echo json_encode(['success' => true, 'message' => $message]);
} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>