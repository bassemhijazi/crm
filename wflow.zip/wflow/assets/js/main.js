// assets/js/main.js
let appData = { users: [], trades: [], accounts: [], jobs: [], technicians: [] };
let currentUserRoleFilter = 'all';

// --- API & DATA HANDLING ---
async function manageData(action, data) { try { const response = await fetch('api/manage_data.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action, data }) }); const result = await response.json(); if (!response.ok) throw new Error(result.message); return result; } catch (error) { console.error(`Error in ${action}:`, error); alert(`Error: ${error.message}`); return { success: false }; } }
async function fetchApiData(type) { try { const response = await fetch(`api/fetch_data.php?type=${type}`); if (!response.ok) throw new Error('Network response was not ok'); return await response.json(); } catch (error) { console.error(`Could not fetch ${type}:`, error); return []; } }
async function loadInitialData() { [appData.users, appData.trades, appData.accounts, appData.jobs, appData.technicians] = await Promise.all([ fetchApiData('users'), fetchApiData('trades'), fetchApiData('accounts'), fetchApiData('jobs'), fetchApiData('technicians') ]); }

// --- INITIALIZATION ---
$(document).ready(async function () {
    await loadInitialData();
    initializeUI();
    initializeEventListeners();
    renderAllContent();
});

function initializeUI() {
    $('.nav-link[data-page="dashboard"]').closest('.nav-item').addClass('active');
    $('#dashboard').addClass('active');
}

function initializeEventListeners() {
    // Main navigation
    $('.nav-link').on('click', function(e) {
        e.preventDefault();
        const pageId = $(this).data('page');
        const roleFilter = $(this).data('role-filter');
        
        $('.nav-item, .nav-item li').removeClass('active');
        $(this).closest('li').addClass('active');
        if ($(this).closest('.collapse').length) {
            $(this).closest('.nav-item').addClass('active');
        }
        
        $('.page').removeClass('active');
        $('#' + pageId).addClass('active');
        
        if (pageId === 'users') {
            currentUserRoleFilter = roleFilter;
            renderUsersTable();
        }
    });
    
    // User modal management
    $('#addUserBtn').on('click', handleAddUserClick);
    $('#usersTableBody').on('click', '.edit-user-btn', handleEditUserClick);
    $('#usersTableBody').on('click', '.delete-user-btn', handleDeleteUser);
    $('#userForm').on('submit', handleSaveUser);
    
    // Job modal management
    $('#jobsTableBody').on('click', '.view-job-details', handleViewJobClick);
    $('#saveJobBtn').on('click', handleSaveJob);
    $('#deleteJobBtn').on('click', handleDeleteJob);
}

function renderAllContent() {
    renderJobsTable();
    renderUsersTable();
}

// --- TABLE RENDERING ---
function renderJobsTable() {
    const tableBody = $("#jobsTableBody");
    tableBody.empty();
    appData.jobs.forEach(job => {
        const row = `
            <tr id="job-row-${job.id}">
                <td>${job.id}</td>
                <td>${job.client}</td>
                <td>${job.trade}</td>
                <td>${job.status}</td>
                <td>${job.tech}</td>
                <td><button class="btn btn-sm btn-outline-primary view-job-details" data-job-id="${job.id}"><i class="fas fa-eye"></i> Details</button></td>
            </tr>`;
        tableBody.append(row);
    });
}

function renderUsersTable() {
    const tableBody = $("#usersTableBody");
    tableBody.empty();

    const titleMap = { all: 'All Users', account_manager: 'Account Managers', team_leader: 'Team Leaders', dispatcher: 'Dispatchers' };
    $('#usersPageTitle').text(titleMap[currentUserRoleFilter]);

    const filteredUsers = currentUserRoleFilter === 'all'
        ? appData.users
        : appData.users.filter(user => user.role === currentUserRoleFilter);
    
    filteredUsers.forEach(user => {
        const row = `
            <tr id="user-row-${user.id}">
                <td>${user.name}</td>
                <td>${user.email}</td>
                <td><span class="badge bg-info text-capitalize">${user.role.replace('_', ' ')}</span></td>
                <td><span class="badge ${user.status === 'Active' ? 'bg-success' : 'bg-secondary'}">${user.status}</span></td>
                <td>
                    <button class="btn btn-sm btn-outline-info edit-user-btn" data-user-id="${user.id}"><i class="fas fa-edit"></i></button>
                    <button class="btn btn-sm btn-outline-danger delete-user-btn" data-user-id="${user.id}"><i class="fas fa-trash"></i></button>
                </td>
            </tr>`;
        tableBody.append(row);
    });
}

// --- USER CRUD HANDLERS ---
function handleAddUserClick() {
    $('#userForm').trigger('reset');
    $('#userForm [name="id"]').val('');
    $('#userModalTitle').text('Add New User');
    $('#userModal').modal('show');
}
function handleEditUserClick() {
    const id = $(this).data('user-id');
    const user = appData.users.find(u => u.id == id);
    if (user) {
        $('#userForm [name="id"]').val(user.id);
        $('#userForm [name="name"]').val(user.name);
        $('#userForm [name="email"]').val(user.email);
        $('#userForm [name="phone"]').val(user.phone);
        $('#userForm [name="role"]').val(user.role);
        $('#userForm [name="status"]').val(user.status);
        $('#userModalTitle').text('Edit User');
        $('#userModal').modal('show');
    }
}
async function handleSaveUser(e) {
    e.preventDefault();
    const form = $(this);
    const userData = {
        id: form.find('[name="id"]').val(),
        name: form.find('[name="name"]').val(),
        email: form.find('[name="email"]').val(),
        phone: form.find('[name="phone"]').val(),
        role: form.find('[name="role"]').val(),
        status: form.find('[name="status"]').val(),
    };
    const action = userData.id ? 'updateUser' : 'addUser';
    const result = await manageData(action, userData);
    if (result.success) {
        $('#userModal').modal('hide');
        await loadInitialData(); // Full refresh to get latest data
        renderUsersTable();
    }
}
async function handleDeleteUser() {
    const id = $(this).data('user-id');
    if (confirm('Are you sure you want to delete this user?')) {
        const result = await manageData('deleteUser', { id });
        if (result.success) {
            appData.users = appData.users.filter(u => u.id != id);
            renderUsersTable();
        }
    }
}

// --- JOB CRUD HANDLERS ---
async function handleViewJobClick() {
    const id = $(this).data('job-id');
    const job = appData.jobs.find(j => j.id === id);
    if (!job) { alert('Job not found!'); return; }
    
    const modalContent = $('#jobDetailsContent');
    const modal = $('#jobDetailsModal');

    // Load form structure from file, then populate it
    modalContent.load('pages/job-details.php', function() {
        modal.find('[name="id"]').val(job.id);
        modal.find('[name="clientSiteName"]').val(job.client);
        modal.find('[name="description"]').val(job.notes);
        modal.find('[name="status"]').val(job.status);
        modal.find('[name="nte"]').val(job.nte);
        modal.find('[name="street"]').val(job.address.street);
        modal.find('[name="city"]').val(job.address.city);
        modal.find('[name="state"]').val(job.address.state);
        modal.find('[name="zip"]').val(job.address.zip);
        
        $('#jobDetailsTitle').text(`Edit Job #${job.id}`);
        modal.modal('show');
    });
}
async function handleSaveJob() {
    const form = $('#editJobForm');
    const jobData = {
        id: form.find('[name="id"]').val(),
        clientSiteName: form.find('[name="clientSiteName"]').val(),
        description: form.find('[name="description"]').val(),
        status: form.find('[name="status"]').val(),
        nte: form.find('[name="nte"]').val(),
        street: form.find('[name="street"]').val(),
        city: form.find('[name="city"]').val(),
        state: form.find('[name="state"]').val(),
        zip: form.find('[name="zip"]').val(),
    };
    const result = await manageData('updateJob', jobData);
    if (result.success) {
        $('#jobDetailsModal').modal('hide');
        await loadInitialData();
        renderJobsTable();
    }
}
async function handleDeleteJob() {
    const id = $('#editJobForm [name="id"]').val();
    if (confirm(`Are you sure you want to delete Job #${id}? This cannot be undone.`)) {
        const result = await manageData('deleteJob', { id });
        if (result.success) {
            $('#jobDetailsModal').modal('hide');
            appData.jobs = appData.jobs.filter(j => j.id !== id);
            renderJobsTable();
        }
    }
}