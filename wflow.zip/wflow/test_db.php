<?php
// test_db.php

echo "Attempting to connect to the database...<br>";

try {
    require_once 'config/database.php';
    echo "<b>Success!</b> The database connection credentials in config/database.php are correct.";
} catch (PDOException $e) {
    echo "<b>Connection Failed!</b> There is an error in your config/database.php file.<br>";
    echo "<b>Error Message:</b> " . $e->getMessage();
}
?>