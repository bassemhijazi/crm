<?php
// config/database.php

$host = 'localhost';
$dbname = 'eventusme_wflow';
$user = 'eventusme_wflow';
$pass = 'oiN7?]+LprU';
$charset = 'utf8mb4';

// Data Source Name
$dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // In a real application, you would log this error and show a user-friendly message.
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed. Please check your configuration.']);
    exit;
}
?>