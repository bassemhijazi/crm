<?php
// includes/sidebar.php
?>
<nav id="sidebar">
    <div class="sidebar-header d-flex align-items-center">
        <i class="fas fa-cogs fa-2x me-2 text-primary"></i>
        <h3>EventusPlat</h3>
    </div>

    <ul class="list-unstyled components">
        <li class="nav-item active"><a href="#" class="nav-link" data-page="dashboard"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a></li>
        <li class="nav-item"><a href="#" class="nav-link" data-page="jobs"><i class="fas fa-briefcase me-2"></i>Jobs</a></li>
        <li class="nav-item"><a href="#" class="nav-link" data-page="accounts"><i class="fas fa-building me-2"></i>Accounts</a></li>
        <li class="nav-item"><a href="#" class="nav-link" data-page="technicians"><i class="fas fa-users-cog me-2"></i>Technicians</a></li>
        <li class="nav-item">
            <a href="#userSubmenu" data-bs-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fas fa-users me-2"></i>Users</a>
            <ul class="collapse list-unstyled" id="userSubmenu">
                <li><a href="#" class="nav-link" data-page="users" data-role-filter="all">All Users</a></li>
                <li><a href="#" class="nav-link" data-page="users" data-role-filter="account_manager">Account Managers</a></li>
                <li><a href="#" class="nav-link" data-page="users" data-role-filter="team_leader">Team Leaders</a></li>
                <li><a href="#" class="nav-link" data-page="users" data-role-filter="dispatcher">Dispatchers</a></li>
            </ul>
        </li>
        <li class="nav-item"><a href="#" class="nav-link" data-page="map"><i class="fas fa-map-marked-alt me-2"></i>Technician Map</a></li>
    </ul>
</nav>