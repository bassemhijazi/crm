<?php
// includes/modals.php
?>
<div class="modal fade" id="jobDetailsModal" tabindex="-1"><div class="modal-dialog modal-xl"><div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="jobDetailsTitle">Job Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
    </div>
    <div class="modal-body" id="jobDetailsContent">
        </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-danger me-auto" id="deleteJobBtn">Delete Job</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="saveJobBtn">Save Changes</button>
    </div>
</div></div></div>

<div class="modal fade" id="userModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="userModalTitle">Add User</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
    </div>
    <div class="modal-body">
        <form id="userForm">
            <input type="hidden" name="id">
            <div class="mb-3"><label class="form-label">Full Name</label><input type="text" class="form-control" name="name" required></div>
            <div class="mb-3"><label class="form-label">Email</label><input type="email" class="form-control" name="email" required></div>
            <div class="mb-3"><label class="form-label">Phone</label><input type="tel" class="form-control" name="phone"></div>
            <div class="mb-3"><label class="form-label">Role</label><select class="form-select" name="role" required>
                <option value="account_manager">Account Manager</option>
                <option value="team_leader">Team Leader</option>
                <option value="dispatcher">Dispatcher</option>
                <option value="admin">Admin</option>
            </select></div>
             <div class="mb-3"><label class="form-label">Status</label><select class="form-select" name="status" required><option>Active</option><option>Inactive</option></select></div>
        </form>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" form="userForm" class="btn btn-primary">Save User</button>
    </div>
</div></div></div>