-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 16, 2025 at 05:25 AM
-- Server version: 8.0.43
-- PHP Version: 8.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eventusme_wflow`
--

-- --------------------------------------------------------

--
-- Table structure for table `Accounts`
--

CREATE TABLE `Accounts` (
  `account_id` char(5) COLLATE utf8mb3_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb3_unicode_ci NOT NULL,
  `billing_terms` varchar(20) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `default_nte` int DEFAULT NULL,
  `sla_profile` varchar(20) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `contact_info` json DEFAULT NULL,
  `address_info` json DEFAULT NULL,
  `active_jobs_count` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `Accounts`
--

INSERT INTO `Accounts` (`account_id`, `name`, `billing_terms`, `default_nte`, `sla_profile`, `contact_info`, `address_info`, `active_jobs_count`) VALUES
('A-001', 'Starbucks Corp', 'Net 30', 750, 'Premium', '{\"email\": \"john@starbucks.com\", \"phone\": \"(555) 123-4567\", \"contact_name\": \"John Smith\"}', '{\"zip\": \"78701\", \"city\": \"Austin\", \"state\": \"TX\", \"street\": \"123 Main St\"}', 3),
('A-002', 'Walmart Inc', 'Net 45', 1000, 'Standard', '{\"email\": \"sarah@walmart.com\", \"phone\": \"(555) 234-5678\", \"contact_name\": \"Sarah Johnson\"}', '{\"zip\": \"78702\", \"city\": \"Austin\", \"state\": \"TX\", \"street\": \"456 Commerce Blvd\"}', 2),
('A-003', 'Target Corporation', 'Net 15', 600, 'Expedited', '{\"email\": \"mike@target.com\", \"phone\": \"(555) 345-6789\", \"contact_name\": \"Mike Williams\"}', '{\"zip\": \"78703\", \"city\": \"Austin\", \"state\": \"TX\", \"street\": \"789 Capital Ln\"}', 1),
('A-004', 'Home Depot', 'Due on Receipt', 800, 'Premium', '{\"email\": \"lisa@homededepot.com\", \"phone\": \"(555) 456-7890\", \"contact_name\": \"Lisa Brown\"}', '{\"zip\": \"78704\", \"city\": \"Austin\", \"state\": \"TX\", \"street\": \"101 Industrial Pkwy\"}', 4);

-- --------------------------------------------------------

--
-- Table structure for table `Compliance`
--

CREATE TABLE `Compliance` (
  `compliance_id` int NOT NULL,
  `tech_id` int NOT NULL,
  `document_name` varchar(100) COLLATE utf8mb3_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb3_unicode_ci NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `file_path` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `Compliance`
--

INSERT INTO `Compliance` (`compliance_id`, `tech_id`, `document_name`, `status`, `expiry_date`, `file_path`) VALUES
(1, 3, 'W-9 Form', 'Uploaded & Verified', NULL, '/docs/tech3/w9_2024.pdf'),
(2, 3, 'Certificate of Insurance (COI)', 'Uploaded & Verified', '2025-06-30', '/docs/tech3/coi_2025.pdf'),
(3, 3, 'Master Plumber License', 'Expires Soon', '2024-08-15', '/docs/tech3/mpl_2024.pdf'),
(4, 3, 'Background Check', 'Completed', '2025-01-10', '/docs/tech3/bg_report.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `Jobs`
--

CREATE TABLE `Jobs` (
  `job_id` char(5) COLLATE utf8mb3_unicode_ci NOT NULL,
  `account_id` char(5) COLLATE utf8mb3_unicode_ci NOT NULL,
  `trade_id` int NOT NULL,
  `status` varchar(30) COLLATE utf8mb3_unicode_ci NOT NULL,
  `sla_due_timestamp` datetime DEFAULT NULL,
  `assigned_team_leader_id` int DEFAULT NULL,
  `assigned_dispatcher_id` int DEFAULT NULL,
  `assigned_tech_id` int DEFAULT NULL,
  `tl_hands_raised` json DEFAULT NULL,
  `dispatcher_hands_raised` json DEFAULT NULL,
  `client_site_name` varchar(100) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `job_description` text COLLATE utf8mb3_unicode_ci,
  `job_location_data` json DEFAULT NULL,
  `nte_amount` int DEFAULT NULL,
  `is_hazardous` tinyint(1) DEFAULT '0',
  `tech_labor_payout` decimal(10,2) DEFAULT '0.00',
  `materials_cost` decimal(10,2) DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `Jobs`
--

INSERT INTO `Jobs` (`job_id`, `account_id`, `trade_id`, `status`, `sla_due_timestamp`, `assigned_team_leader_id`, `assigned_dispatcher_id`, `assigned_tech_id`, `tl_hands_raised`, `dispatcher_hands_raised`, `client_site_name`, `job_description`, `job_location_data`, `nte_amount`, `is_hazardous`, `tech_labor_payout`, `materials_cost`) VALUES
('J-001', 'A-001', 1, 'Pending Assignment', '2025-10-16 12:34:51', NULL, NULL, NULL, '[3, 5]', '[]', 'Starbucks #452', 'Leaky faucet in main restroom. Team Leaders have bid.', '{\"lat\": 30.2672, \"lng\": -97.7431}', 500, 0, 0.00, 0.00),
('J-002', 'A-002', 2, 'Pending Dispatcher', '2025-10-16 12:04:51', 3, NULL, NULL, '[3]', '[4]', 'Walmart #1023', 'AC unit not cooling. Dispatchers have bid.', '{\"lat\": 30.2712, \"lng\": -97.7501}', 750, 0, 0.00, 0.00),
('J-003', 'A-003', 3, 'Ready for Tech Offer', '2025-10-16 13:34:51', 3, 4, NULL, '[3]', '[4]', 'Target #T-21', 'Flickering lights in aisle 5. Waiting for tech.', '{\"lat\": 30.2622, \"lng\": -97.7391}', 600, 0, 450.00, 0.00),
('J-004', 'A-004', 1, 'En-route', '2025-10-16 12:49:51', 5, 4, 4, '[5]', '[4]', 'Home Depot #HD-55', 'Clogged drain in garden center.', '{\"lat\": 30.28, \"lng\": -97.745}', 400, 0, 200.00, 45.25),
('J-005', 'A-001', 4, 'Work Started', '2025-10-16 12:49:51', 3, 4, 5, '[3]', '[4]', 'Starbucks #781', 'Install new shelving in storage room.', '{\"lat\": 30.29, \"lng\": -97.76}', 350, 0, 150.00, 89.99);

-- --------------------------------------------------------

--
-- Table structure for table `Messaging`
--

CREATE TABLE `Messaging` (
  `message_id` int NOT NULL,
  `job_id` char(5) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `sender_user_id` int DEFAULT NULL,
  `recipient_tech_id` int NOT NULL,
  `message_content` text COLLATE utf8mb3_unicode_ci NOT NULL,
  `sent_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `is_outgoing` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `Messaging`
--

INSERT INTO `Messaging` (`message_id`, `job_id`, `sender_user_id`, `recipient_tech_id`, `message_content`, `sent_at`, `is_outgoing`) VALUES
(1, 'J-003', 4, 3, 'System: Job offer J-003 has been sent to Mike Johnson (Electrical) for $450.', '2025-10-16 05:09:16', 1),
(2, 'J-003', 4, 3, 'Dispatcher: Mike, please confirm the panel access. Is it accessible?', '2025-10-16 05:09:16', 1),
(3, 'J-003', NULL, 3, 'Mike Johnson: Got the offer! Looks accessible based on the site photos. I\'m raising my hand.', '2025-10-16 05:09:16', 0),
(4, 'J-003', NULL, 3, 'Mike Johnson: JOB ACCEPTED. Estimated arrival 30 minutes.', '2025-10-16 05:09:16', 0);

-- --------------------------------------------------------

--
-- Table structure for table `Technicians`
--

CREATE TABLE `Technicians` (
  `tech_id` int NOT NULL,
  `full_name` varchar(100) COLLATE utf8mb3_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb3_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb3_unicode_ci NOT NULL,
  `rating` int DEFAULT NULL,
  `score` int DEFAULT NULL,
  `coverage_radius_miles` int DEFAULT NULL,
  `primary_trade_id` int DEFAULT NULL,
  `location_data` json DEFAULT NULL,
  `payout_preference_1` varchar(20) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `payout_preference_2` varchar(20) COLLATE utf8mb3_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `Technicians`
--

INSERT INTO `Technicians` (`tech_id`, `full_name`, `phone`, `email`, `status`, `rating`, `score`, `coverage_radius_miles`, `primary_trade_id`, `location_data`, `payout_preference_1`, `payout_preference_2`) VALUES
(1, 'John Doe', '555-1234', NULL, 'Certified', 6, 95, 50, 1, '{\"lat\": 30.2672, \"lng\": -97.7431}', 'ACH', 'Zelle'),
(2, 'Jane Smith', '555-5678', NULL, 'Certified', 5, 88, 75, 2, '{\"lat\": 30.2712, \"lng\": -97.7501}', 'Zelle', 'PayPal'),
(3, 'Mike Johnson', '555-9012', NULL, 'Validated', 4, 72, 60, 3, '{\"lat\": 30.2622, \"lng\": -97.7391}', 'ACH', 'Venmo'),
(4, 'Emily White', '555-3456', NULL, 'Certified', 7, 98, 40, 1, '{\"lat\": 30.28, \"lng\": -97.745}', 'Zelle', 'ACH'),
(5, 'Chris Green', '555-7890', NULL, 'Prospect', 3, 65, 100, 4, '{\"lat\": 30.3072, \"lng\": -97.7031}', 'PayPal', 'Venmo'),
(6, 'Robert Davis', '555-1122', NULL, 'Validated', 5, 81, 45, 5, '{\"lat\": 30.275, \"lng\": -97.73}', 'ACH', 'PayPal'),
(7, 'Maria Garcia', '555-3344', NULL, 'Certified', 6, 92, 80, 6, '{\"lat\": 30.285, \"lng\": -97.72}', 'Zelle', 'Venmo');

-- --------------------------------------------------------

--
-- Table structure for table `Trades`
--

CREATE TABLE `Trades` (
  `trade_id` int NOT NULL,
  `name` varchar(50) COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb3_unicode_ci,
  `status` varchar(10) COLLATE utf8mb3_unicode_ci NOT NULL,
  `default_nte` int DEFAULT NULL,
  `trade_color` char(7) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `requires_license` tinyint(1) DEFAULT '0',
  `is_hazardous` tinyint(1) DEFAULT '0',
  `technician_count` int DEFAULT '0',
  `active_job_count` int DEFAULT '0',
  `avg_margin` decimal(5,2) DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `Trades`
--

INSERT INTO `Trades` (`trade_id`, `name`, `description`, `status`, `default_nte`, `trade_color`, `requires_license`, `is_hazardous`, `technician_count`, `active_job_count`, `avg_margin`) VALUES
(1, 'Plumbing', 'Pipe installation, repair, and maintenance', 'active', 500, '#fd7e14', 1, 0, 2, 2, 35.00),
(2, 'HVAC', 'Heating, ventilation, and air conditioning', 'active', 750, '#0dcaf0', 1, 0, 2, 1, 45.00),
(3, 'Electrical', 'Electrical systems installation and repair', 'active', 600, '#ffc107', 1, 0, 1, 1, 28.00),
(4, 'Handyman', 'General repairs and maintenance', 'active', 350, '#6c757d', 0, 0, 1, 1, 25.00),
(5, 'Carpentry', 'Woodwork and structural repairs', 'active', 450, '#d63384', 0, 0, 1, 0, 40.00),
(6, 'Roofing', 'Roof installation and repair', 'active', 1200, '#dc3545', 1, 0, 1, 0, 38.00),
(7, 'Landscaping', 'Grounds maintenance and landscaping', 'inactive', 400, '#198754', 0, 0, 0, 0, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE `Users` (
  `user_id` int NOT NULL,
  `full_name` varchar(100) COLLATE utf8mb3_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `role` varchar(20) COLLATE utf8mb3_unicode_ci NOT NULL,
  `status` varchar(10) COLLATE utf8mb3_unicode_ci NOT NULL,
  `password_hash` char(64) COLLATE utf8mb3_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`user_id`, `full_name`, `email`, `phone`, `role`, `status`, `password_hash`) VALUES
(1, 'Alice Admin', 'alice.a@eventus.com', '555-1001', 'admin', 'Active', 'demo'),
(2, 'Mike Manager', 'mike.m@eventus.com', '555-1002', 'account_manager', 'Active', 'demo'),
(3, 'Linda Leader', 'linda.l@eventus.com', '555-1003', 'team_leader', 'Active', 'demo'),
(4, 'David Dispatcher', 'david.d@eventus.com', '555-1004', 'dispatcher', 'Active', 'demo'),
(5, 'Leo Leader 2', 'leo.l2@eventus.com', '555-1005', 'team_leader', 'Inactive', 'demo');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Accounts`
--
ALTER TABLE `Accounts`
  ADD PRIMARY KEY (`account_id`);

--
-- Indexes for table `Compliance`
--
ALTER TABLE `Compliance`
  ADD PRIMARY KEY (`compliance_id`),
  ADD KEY `tech_id` (`tech_id`);

--
-- Indexes for table `Jobs`
--
ALTER TABLE `Jobs`
  ADD PRIMARY KEY (`job_id`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `trade_id` (`trade_id`),
  ADD KEY `assigned_team_leader_id` (`assigned_team_leader_id`),
  ADD KEY `assigned_dispatcher_id` (`assigned_dispatcher_id`),
  ADD KEY `assigned_tech_id` (`assigned_tech_id`);

--
-- Indexes for table `Messaging`
--
ALTER TABLE `Messaging`
  ADD PRIMARY KEY (`message_id`),
  ADD KEY `job_id` (`job_id`),
  ADD KEY `sender_user_id` (`sender_user_id`),
  ADD KEY `recipient_tech_id` (`recipient_tech_id`);

--
-- Indexes for table `Technicians`
--
ALTER TABLE `Technicians`
  ADD PRIMARY KEY (`tech_id`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD KEY `primary_trade_id` (`primary_trade_id`);

--
-- Indexes for table `Trades`
--
ALTER TABLE `Trades`
  ADD PRIMARY KEY (`trade_id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Compliance`
--
ALTER TABLE `Compliance`
  MODIFY `compliance_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `Messaging`
--
ALTER TABLE `Messaging`
  MODIFY `message_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `Technicians`
--
ALTER TABLE `Technicians`
  MODIFY `tech_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `Trades`
--
ALTER TABLE `Trades`
  MODIFY `trade_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `Users`
--
ALTER TABLE `Users`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Compliance`
--
ALTER TABLE `Compliance`
  ADD CONSTRAINT `Compliance_ibfk_1` FOREIGN KEY (`tech_id`) REFERENCES `Technicians` (`tech_id`);

--
-- Constraints for table `Jobs`
--
ALTER TABLE `Jobs`
  ADD CONSTRAINT `Jobs_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `Accounts` (`account_id`),
  ADD CONSTRAINT `Jobs_ibfk_2` FOREIGN KEY (`trade_id`) REFERENCES `Trades` (`trade_id`),
  ADD CONSTRAINT `Jobs_ibfk_3` FOREIGN KEY (`assigned_team_leader_id`) REFERENCES `Users` (`user_id`),
  ADD CONSTRAINT `Jobs_ibfk_4` FOREIGN KEY (`assigned_dispatcher_id`) REFERENCES `Users` (`user_id`),
  ADD CONSTRAINT `Jobs_ibfk_5` FOREIGN KEY (`assigned_tech_id`) REFERENCES `Technicians` (`tech_id`);

--
-- Constraints for table `Messaging`
--
ALTER TABLE `Messaging`
  ADD CONSTRAINT `Messaging_ibfk_1` FOREIGN KEY (`job_id`) REFERENCES `Jobs` (`job_id`),
  ADD CONSTRAINT `Messaging_ibfk_2` FOREIGN KEY (`sender_user_id`) REFERENCES `Users` (`user_id`),
  ADD CONSTRAINT `Messaging_ibfk_3` FOREIGN KEY (`recipient_tech_id`) REFERENCES `Technicians` (`tech_id`);

--
-- Constraints for table `Technicians`
--
ALTER TABLE `Technicians`
  ADD CONSTRAINT `Technicians_ibfk_1` FOREIGN KEY (`primary_trade_id`) REFERENCES `Trades` (`trade_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;